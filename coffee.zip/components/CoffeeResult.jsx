/* day08/src/components/CoffeeResult.jsx */
// CoffeeResult.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import styles from '../css/Coffee.module.css';

const CoffeeResult = ({ showResult }) => {
    const coffeeMenu = useSelector(state => state.coffee.menu);

    // 총합 계산
    const totalAmount = coffeeMenu
    .filter(item => item.qty > 0)
    .reduce((sum, item) => sum + (item.price * item.qty), 0);

    // showResult가 true일 때만 렌더링
    if (!showResult) {
        return null;
    }

    return (
        <div className={styles.receiptContainer}>
            <h2 className={styles.receiptTitle}>영수증</h2>
            <table className={styles.receiptTable}>
                <thead>
                    <tr>
                        <th>커피</th>
                        <th>수량</th>
                        <th>금액</th>
                    </tr>
                </thead>
                <tbody>
                    {coffeeMenu
                        .filter(item => item.qty > 0)
                        .map(item => (
                            <tr key={item.name}>
                                <td>{item.name}</td>
                                <td>{item.qty}개</td>
                                <td>{(item.price * item.qty).toLocaleString()}원</td>
                            </tr>
                        ))
                    }
                </tbody>
                <tfoot>
                    <tr>
                        <td colSpan="2" className={styles.totalLabel}>총 합계</td>
                        <td className={styles.totalAmount}>{totalAmount.toLocaleString()}원</td>
                    </tr>
                </tfoot>
            </table>
        </div>
    );
};

export default CoffeeResult;
