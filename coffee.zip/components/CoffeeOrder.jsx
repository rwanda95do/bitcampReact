/* day08/src/components/CoffeeOrder.jsx */

import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { americano, cafelatte, cappuccino } from '../store/modules/coffee';
import CoffeeResult from './CoffeeResult';
import styles from '../css/Coffee.module.css';

const CoffeeOrder = () => {
    const dispatch = useDispatch();
    const [showResult, setShowResult] = useState(false);

    const onQtyChange = (name, qty) => {
        setShowResult(false);

        switch (name) {
            case '아메리카노':
                dispatch(americano(qty));
                break;
            case '카페라떼':
                dispatch(cafelatte(qty));
                break;
            case '카푸치노':
                dispatch(cappuccino(qty));
                break;
            default:
                break;
        }
    };

    const onOrder = () => {
        setShowResult(true);
    };

    return (
        <div>
        <div className={styles.orderContainer}>
            <h2 className={styles.receiptTitle}>주문서</h2>
            <div className={styles.orderRow}>
                <span>아메리카노</span>
                <input 
                    type="number" 
                    min="0" 
                    onChange={(e) => onQtyChange('아메리카노', parseInt(e.target.value) || 0)} 
                />
            </div>
            <div className={styles.orderRow}>
                <span>카페라떼</span>
                <input 
                    type="number" 
                    min="0" 
                    onChange={(e) => onQtyChange('카페라떼', parseInt(e.target.value) || 0)} 
                />
            </div>
            <div className={styles.orderRow}>
                <span>카푸치노</span>
                <input 
                    type="number" 
                    min="0" 
                    onChange={(e) => onQtyChange('카푸치노', parseInt(e.target.value) || 0)} 
                />
            </div>
            <button onClick={onOrder} className={styles.orderButton}>주문</button>

        </div>
            <CoffeeResult showResult={showResult} />
        </div>
    );
};

export default CoffeeOrder;
