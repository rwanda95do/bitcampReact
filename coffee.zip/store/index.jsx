// day08/src/store/index.jsx 
// components/Color.jsx 와 store/modules/color.jsx 연결
// components/Count.jsx 와 store/modules/count.jsx 연결
// count와 color 리듀서를 결합하여 rootReducer를 생성
// rootReducer는 Redux store에서 사용 가능

import { combineReducers } from "redux";
import color from './modules/color'; 
import count from './modules/count';
import animal from './modules/animal';
import coffee from './modules/coffee';

export default combineReducers({
    color: color, // 리듀서 이름 : 리듀서 값
    count, // 이름과 값이 같으면 하나만 써도 됨
    // count: count // count 리듀서 연결
    animal,
    coffee
});

