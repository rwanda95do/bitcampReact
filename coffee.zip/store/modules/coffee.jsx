// day08/src/store/modules/coffee.jsx

/* 1. 액션 생성 */
// 모듈 이름을 앞에 붙여주어서 액션명 중복 방지
const AMERICANO = 'coffee/AMERICANO';
const CAFELATTE = 'coffee/CAFELATTE';
const CAPPUCCINO = 'coffee/CAPPUCCINO';

/* 2. 액션 전송; type 속성으로 액션 객체에 포함 */
export const americano = (qty) => ({ type: AMERICANO, qty });
export const cafelatte = (qty) => ({ type: CAFELATTE, qty });
export const cappuccino = (qty) => ({ type: CAPPUCCINO, qty });

/* 3. 초기값 설정 */
const initialState = {
    menu: [
        { name: '아메리카노', price: 1500, qty: 0 },
        { name: '카페라떼', price: 2500, qty: 0 },
        { name: '카푸치노', price: 3000, qty: 0 }
    ]
};

/* 4. 리듀서 생성 ; state, action 파라미터를 참조하여 새로운 상태 객체를 만듦 */
// state: 현재 상태, action : 액션 객체
// 반드시 state 에는 초기값을 주어야 함
const reducer = (state = initialState, action) => {
    switch (action.type) {
        case AMERICANO:
            return {
                ...state,
                menu: state.menu.map(item =>
                    item.name === '아메리카노' ? { ...item, qty: action.qty } : item
                )
            };
        case CAFELATTE:
            return {
                ...state,
                menu: state.menu.map(item =>
                    item.name === '카페라떼' ? { ...item, qty: action.qty } : item
                )
            };
        case CAPPUCCINO:
            return {
                ...state,
                menu: state.menu.map(item =>
                    item.name === '카푸치노' ? { ...item, qty: action.qty } : item
                )
            };
        default:
            return state;
    }
};


/* 5. reducer export */
export default reducer 
