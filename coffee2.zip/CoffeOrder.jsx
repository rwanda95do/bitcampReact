import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { americano, cafelatte, cappuccino, refund } from '../store/modules/coffee';
import CoffeeResult from './CoffeeResult';
import styles from '../css/Coffee.module.css';

const CoffeeOrder = () => {
    const dispatch = useDispatch();
    const [showResult, setShowResult] = useState(false);

    const [list, setList] = useState([
        { name: "americano", qty: 0 },
        { name: "cafelatte", qty: 0 },
        { name: "cappuccino", qty: 0 },
    ]);

    const onQtyChange = (name, qty) => {
        const newList = list.map(item =>
            item.name === name ? { ...item, qty } : item
        );
        setList(newList);
        setShowResult(false);
    };

    const onOrder = () => {
        list.forEach(coffee => {
            if (coffee.qty > 0) {
                switch (coffee.name) {
                    case "americano":
                        dispatch(americano(coffee.qty));
                        break;
                    case "cafelatte":
                        dispatch(cafelatte(coffee.qty));
                        break;
                    case "cappuccino":
                        dispatch(cappuccino(coffee.qty));
                        break;
                    default:
                        break;
                }
            }
        });
        setShowResult(true);
    };

    const onReset = () => {
        dispatch(refund());
        setList(list.map(item => ({ ...item, qty: 0 }))); // 목록의 qty도 0으로 초기화
    };

    return (
        <div>
            <div className={styles.orderContainer}>
                <h2 className={styles.receiptTitle}>주문서</h2>
                {list.map(coffee => (
                    <div key={coffee.name} className={styles.orderRow}>
                        <span>{coffee.name === 'americano' ? '아메리카노' : coffee.name === 'cafelatte' ? '카페라떼' : '카푸치노'}</span>
                        <input
                            type="number"
                            min="0"
                            value={coffee.qty}
                            onChange={(e) => onQtyChange(coffee.name, parseInt(e.target.value) || 0)}
                            style={{ width: '50px', marginLeft: '10px', display: 'inline-block' }} // 인풋을 한 줄로 표시
                        />
                    </div>
                ))}
                <button onClick={onOrder} className={styles.orderButton}>주문</button>
                <button onClick={onReset} className={styles.orderButton}>환불</button>
            </div>
            <CoffeeResult showResult={showResult} />
        </div>
    );
};

export default CoffeeOrder;
