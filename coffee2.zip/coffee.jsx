/* 1. 액션 생성 */
const AMERICANO = 'coffee/AMERICANO';
const CAFELATTE = 'coffee/CAFELATTE';
const CAPPUCCINO = 'coffee/CAPPUCCINO';
const REFUND = 'coffee/REFUND';

/* 2. 액션 전송; type 속성으로 액션 객체에 포함 */
export const americano = (qty) => ({ type: AMERICANO, qty });
export const cafelatte = (qty) => ({ type: CAFELATTE, qty });
export const cappuccino = (qty) => ({ type: CAPPUCCINO, qty });
export const refund = () => ({ type: REFUND });

/* 3. 초기값 설정 */
const initialState = {
    menu: [
        { name: '아메리카노', price: 1500, qty: 0 },
        { name: '카페라떼', price: 2500, qty: 0 },
        { name: '카푸치노', price: 3000, qty: 0 }
    ]
};

/* 4. 리듀서 생성 */
const reducer = (state = initialState, action) => {
    switch (action.type) {
        case REFUND:
            return initialState;
        case AMERICANO:
        case CAFELATTE:
        case CAPPUCCINO:
            return {
                ...state,
                menu: state.menu.map(item =>
                    item.name === (action.type === AMERICANO ? '아메리카노' : action.type === CAFELATTE ? '카페라떼' : '카푸치노')
                        ? { ...item, qty: item.qty + action.qty } : item
                )
            };
        default:
            return state;
    }
};

export default reducer;
